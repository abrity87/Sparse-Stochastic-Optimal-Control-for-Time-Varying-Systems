import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Set font and font size
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12

# Deterministic system simulation
t1_end = 1.9975
t2_start = t1_end
t2_end = 2.0025
t3_start = t2_end
t_end = 4.0

# Define ODE functions
def ode_func1(s, x):
    return s * x + (s - 2) * (-1)  # u=-1

def ode_func2(s, x):
    return s * x  # u=0

def ode_func3(s, x):
    return s * x + (s - 2) * 1  # u=1

# Integration interval 1
sol1 = solve_ivp(ode_func1, [0, t1_end], [0.0], t_eval=np.linspace(0, t1_end, 500))
t1, x1 = sol1.t, sol1.y[0]

# Integration interval 2
sol2 = solve_ivp(ode_func2, [t2_start, t2_end], [x1[-1]], t_eval=np.linspace(t2_start, t2_end, 10))
t2, x2 = sol2.t, sol2.y[0]

# Integration interval 3
sol3 = solve_ivp(ode_func3, [t3_start, t_end], [x2[-1]], t_eval=np.linspace(t3_start, t_end, 500))
t3, x3 = sol3.t, sol3.y[0]

# Combine results
t_det = np.concatenate([t1, t2, t3])
x_det = np.concatenate([x1, x2, x3])
u_det = np.piecewise(t_det, [t_det < t1_end, (t_det >= t1_end) & (t_det <= t2_end), t_det > t2_end], [-1, 0, 1])

# Stochastic system simulation
N = 50  # Number of sample paths
dt = 0.001
t_sde = np.arange(0, t_end + dt, dt)
num_steps = len(t_sde)
x_sde = np.zeros((num_steps, N))
np.random.seed(42)

for n in range(N):
    x = 0.0
    x_sde[0, n] = x
    dW = np.sqrt(dt) * np.random.randn(num_steps - 1)
    for i in range(num_steps - 1):
        s = t_sde[i]
        if s < t1_end:
            u = -1
        elif t1_end < s < t2_end:
            u = 0
        else:
            u = 1
        deterministic = (s * x + (s - 2) * u) * dt
        x += deterministic + dW[i]
        x_sde[i+1, n] = x

mean_x_sde = np.mean(x_sde, axis=1)
u_sde = np.piecewise(t_sde, [t_sde < t1_end, (t_sde >= t1_end) & (t_sde <= t2_end), t_sde > t2_end], [-1, 0, 1])

# Plotting
fig, axs = plt.subplots(2, 1, figsize=(8, 6), tight_layout=True)

# Deterministic system
ax1 = axs[0]
ax1.plot(t_det, x_det, color='b', label='State $x(s)$')
ax1.set_ylabel('State $x(s)$', color='b')
ax1.tick_params(axis='y', labelcolor='b')
ax1.grid(True, linestyle='--', alpha=0.7)
ax1_step = ax1.twinx()
ax1_step.step(t_det, u_det, where='post', color='r', linestyle='--', label='Control $u(s)$')
ax1_step.set_ylabel('Control $u(s)$', color='r')
ax1_step.tick_params(axis='y', labelcolor='r')
ax1.set_title('(a) Deterministic System')

# Stochastic system
ax2 = axs[1]
for n in range(N):
    ax2.plot(t_sde, x_sde[:, n], color='gray', linewidth=0.5, alpha=0.5)
ax2.plot(t_sde, mean_x_sde, color='b', label='Mean State')
ax2.set_xlabel('Time $s$')
ax2.set_ylabel('State $x(s)$', color='b')
ax2.tick_params(axis='y', labelcolor='b')
ax2.grid(True, linestyle='--', alpha=0.7)
ax2_step = ax2.twinx()
ax2_step.step(t_sde, u_sde, where='post', color='r', linestyle='--', label='Control $u(s)$')
ax2_step.set_ylabel('Control $u(s)$', color='r')
ax2_step.tick_params(axis='y', labelcolor='r')
ax2.set_title('(b) Stochastic System')

plt.savefig('Fig2.png', dpi=300, bbox_inches='tight')
plt.show()
