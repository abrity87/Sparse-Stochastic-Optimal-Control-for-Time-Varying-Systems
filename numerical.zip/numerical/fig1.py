import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({
    'font.family': 'Times New Roman',  # Global font type
    'font.size': 10,                   # Global font size
    'axes.labelsize': 10,              # Axis label font size
    'axes.linewidth': 1.0,             # Axis line width
    'xtick.labelsize': 8,              # x-axis tick label font size
    'ytick.labelsize': 8,              # y-axis tick label font size
    'xtick.direction': 'in',           # Tick direction
    'ytick.direction': 'in',
    'lines.linewidth': 1.5,            # Line width
    'legend.fontsize': 8,              # Legend font size
    'legend.frameon': False,           # Turn off legend frame
    'mathtext.default': 'regular'      # Math text font
})

# ====================
# Data Preparation
# ====================
s = np.linspace(0, 4, 1000)

# Case 1: Time-Invariant
p1 = np.exp(4 - s)
u1 = np.ones_like(s)

# Case 2: Time-Varying
p2 = np.exp(8 - 0.5 * s**2)
prod = (s - 2) * p2
s1, s2 = 1.9975, 2.0025
u2 = np.piecewise(s, [s < s1, (s >= s1) & (s <= s2), s > s2], [-1, 0, 1])

# ====================
# Main Plot
# ====================
fig = plt.figure(figsize=(7, 5))  # Single column standard size (inches)

# ---- Case 1 Control Variable ----
ax1 = plt.subplot(2, 2, 1)
ax1.plot(s, u1, color='r')  # Using standard red
ax1.set_title('(a) Optimal Control', y=1.0, pad=-14)  # Adjust title position
ax1.set_ylim(-1.1, 1.1)
ax1.set_ylabel('Control $u^*(s)$', labelpad=2)

# ---- Case 1 Adjoint Variable ----
ax2 = plt.subplot(2, 2, 2)
ax2.plot(s, p1, color='#ff7f0e')  # Using standard orange
ax2.set_title('(b) Adjoint Variable', y=1.0, pad=-14)
ax2.set_ylabel('$p(s)$', labelpad=2)

# ---- Case 2 Control Variable ----
ax3 = plt.subplot(2, 2, 3)
ax3.plot(s, u2, color='r')
for sp in [s1, s2]:
    ax3.axvline(x=sp, color='gray', linestyle=':', linewidth=1.0, alpha=0.8)
ax3.set_title('(c) Piecewise Control', y=1.0, pad=-14)
ax3.set_ylim(-1.1, 1.1)
ax3.set_xlabel('Time $s$', labelpad=2)
ax3.set_ylabel('Control $u^*(s)$', labelpad=2)

# ---- Case 2 Switching Function ----
ax4 = plt.subplot(2, 2, 4)
ax4.plot(s, prod, color='#2ca02c', label='$(s-2)p(s)$')  # Using standard green
ax4.axhline(1, color='#d62728', linestyle='--', linewidth=1.0)  # Red dashed line
ax4.axhline(-1, color='#9467bd', linestyle='--', linewidth=1.0)  # Purple dashed line
ax4.fill_between(s, prod, 1, where=(prod>1), color='#d62728', alpha=0.15)
ax4.fill_between(s, prod, -1, where=(prod<-1), color='#9467bd', alpha=0.15)
ax4.set_title('(d) Switching Function', y=1.0, pad=-14)
ax4.set_xlabel('Time $s$', labelpad=2)
ax4.legend(loc='upper right', handlelength=2.5)

# Common settings for all axes
for ax in [ax1, ax2, ax3, ax4]:
    ax.grid(True, linestyle=':', alpha=0.6)
    ax.tick_params(axis='both', which='both', pad=2)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    if ax in [ax1, ax2]:
        ax.set_xticklabels([])
        ax.set_xlabel('')

plt.tight_layout(w_pad=1.5, h_pad=2.5)
plt.savefig('Figure1-1.png', dpi=300, bbox_inches='tight')  

# ====================
# Adjoint Variable Comparison
# ====================
fig2 = plt.figure(figsize=(7, 3))

ax21 = fig2.add_subplot(121)
ax21.plot(s, p1, color='#ff7f0e')
ax21.set_title('Case 1: $p(s)=e^{4-s}$', pad=10)
ax21.set_xlabel('Time $s$', labelpad=2)
ax21.set_ylabel('$p(s)$', labelpad=2)

ax22 = fig2.add_subplot(122)
ax22.plot(s, p2, color='#ff7f0e')
ax22.set_title('Case 2: $p(s)=e^{8-\\frac{1}{2}s^2}$', pad=10)
ax22.set_xlabel('Time $s$', labelpad=2)

for ax in [ax21, ax22]:
    ax.grid(True, linestyle=':', alpha=0.6)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.tick_params(axis='both', which='both', pad=2)

plt.tight_layout(w_pad=3.0)
plt.savefig('Fig1.png', dpi=300, bbox_inches='tight')

plt.show()
