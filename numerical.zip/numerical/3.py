import numpy as np
import matplotlib.pyplot as plt

# Parameter settings
E0 = 0.5      # Initial energy storage
E_ref = 0.5   # Target energy level
E_safe = 0.3  # Safety energy threshold
P_load = 0.8  # Load power
sigma = 0.2   # Noise intensity
T = 24        # Time horizon (hours)
N = 1000      # Number of time steps
t = np.linspace(0, T, N)
dt = t[1] - t[0]
# Solar power generation model
Psolar = 1 + 0.5 * np.sin(2 * np.pi * t / T)

# Optimal control solution
u = np.zeros(N)  # Initial control strategy
max_iter = 50     # Maximum iterations

for _ in range(max_iter):
    # Forward solve state equation
    E = np.zeros(N)
    E[0] = E0
    for i in range(N-1):
        E[i+1] = E[i] + (Psolar[i] - u[i]*P_load) * dt
    
    # Backward solve adjoint equation
    p = np.zeros(N)
    p[-1] = 200 * (E[-1] - E_safe)  # Terminal condition
    for i in range(N-2, -1, -1):
        p[i] = p[i+1] + 20*(E[i] - E_ref)*dt
    
    # Update control strategy
    new_u = np.zeros(N)
    for i in range(N):
        H0 = 10*(E[i]-E_ref)**2 + p[i]*Psolar[i]
        H1 = 1 + 10*(E[i]-E_ref)**2 + p[i]*(Psolar[i]-P_load)
        new_u[i] = 1 if H1 < H0 else 0
    
    if np.allclose(u, new_u):
        break
    u = new_u.copy()

# Stochastic simulation - Run multiple times to obtain confidence interval
np.random.seed(42)
num_simulations = 2000  # Increase simulations for better confidence interval estimation
E_stoch_matrix = np.zeros((num_simulations, N))

for j in range(num_simulations):
    E_stoch = np.zeros(N)
    E_stoch[0] = E0
    for i in range(N-1):
        dW = np.random.normal(0, np.sqrt(dt))
        E_stoch[i+1] = E_stoch[i] + (Psolar[i] - u[i]*P_load)*dt + sigma*dW
    E_stoch_matrix[j, :] = E_stoch

# Calculate confidence interval
E_mean = np.mean(E_stoch_matrix, axis=0)
E_std = np.std(E_stoch_matrix, axis=0)
E_low = E_mean - 1.96 * E_std  # 95% confidence interval lower bound
E_high = E_mean + 1.96 * E_std  # 95% confidence interval upper bound

plt.rcParams.update({
    "font.family": "Arial",
    "font.size": 10,
    "axes.labelsize": 10,
    "legend.fontsize": 8,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "axes.unicode_minus": False,
    "figure.constrained_layout.use": True
})

# Create 2x2 subplot grid
fig, axs = plt.subplots(2, 2, figsize=(8, 6), sharex=True)
fig.set_constrained_layout_pads(w_pad=4./72, h_pad=4./72)

# First row, first column: Solar power
axs[0,0].plot(t, Psolar, color='C0', linewidth=1)
axs[0,0].set_ylabel('$P_{\mathrm{solar}}(s)$\n(p.u.)', labelpad=8)
axs[0,0].set_title('(a) Solar Power Generation', pad=10)

# Second row, first column: Control signal
axs[1,0].step(t, u, where='post', color='C1', linewidth=0.8)
axs[1,0].set_ylabel('$u(s)$', labelpad=8)
axs[1,0].set_yticks([0, 1])
axs[1,0].set_title('(b) Control Signal', pad=10)

# First row, second column: Energy state
axs[0,1].plot(t, E, color='C2', linewidth=1, label='Deterministic')     # Deterministic model
axs[0,1].fill_between(t, E_low, E_high, color='C3', alpha=0.25, lw=0,
                    label='95% Confidence')
# Use first simulation as example stochastic trajectory
axs[0,1].plot(t, E_stoch_matrix[0], color='C3', alpha=0.7, linewidth=1, label='Stochastic')
axs[0,1].axhline(E_ref, color='#d62728', ls='--', linewidth=1, label='Reference')  # Reference line
axs[0,1].axhline(E_safe, color='#ff7f0e', ls=':', linewidth=1, label='Safety')     # Safety line
axs[0,1].set_ylabel('$E(s)$\n(p.u.)', labelpad=8)
axs[0,1].legend(loc='upper left', frameon=False, handlelength=1.5)
axs[0,1].set_title('(c) Energy State Dynamics', pad=10)

# Second row, second column: Adjoint variable
axs[1,1].plot(t, p, color='C4', linewidth=1)
axs[1,1].set_ylabel('$p(s)$\n(dual)', labelpad=8)
axs[1,1].set_xlabel('Time (h)', labelpad=8)
axs[1,1].set_title('(d) Dual Variable', pad=10)

# Unified x-axis settings
for ax in axs.flat:
    ax.tick_params(axis='x', which='both', pad=2)
    ax.set_xlim(0, 24)
    ax.xaxis.set_major_locator(plt.MultipleLocator(6))
    ax.xaxis.set_minor_locator(plt.MultipleLocator(3))
    ax.grid(True, which='major', linestyle=':', linewidth=0.5)

plt.savefig('Fig3.png',
            dpi=600, bbox_inches='tight',
            metadata={'CreationDate': None},
            pad_inches=0.05)
plt.show()
